package datatable;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Calendar;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Datatable {
	public static Workbook wb;
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public int rowCount(String FileName,String SheetName)
	{
		Workbook wb;
		Sheet sh;
		int rc=-1;
		FileInputStream fin=null;
		try
		{
			fin=new FileInputStream(FileName);
			wb=new XSSFWorkbook(fin);
			int index=wb.getSheetIndex(SheetName);
			if (index==-1) return -1;
			sh=wb.getSheet(SheetName);
			rc=sh.getPhysicalNumberOfRows();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}finally
		{
			try
			{
				fin.close();
				wb=null;
				sh=null;
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return rc-1;
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public int rowCount(String SheetName)
	{
		Sheet sh;
		int rc=-1;
		try
		{
			sh=wb.getSheet(SheetName);
			int index=wb.getSheetIndex(SheetName);
			if (index==-1) return -1;
			rc=sh.getLastRowNum();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return rc;
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public boolean importExcelFile(String FileName)
	{
		FileInputStream fin=null;
		try
		{
			fin=new FileInputStream(FileName);
			wb=new XSSFWorkbook(fin);
			if (wb==null) return false;
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fin.close();
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return true;
	}
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */

	public String getCellValue(String FileName,String SheetName,String colName,int rownum)
	{
		Workbook wb;
		Sheet sh;
		Row row;
		Cell cell;
		int colNum = 0;
		String cellData=null;
		FileInputStream fin=null;
		try
		{
			fin=new FileInputStream(FileName);
			wb=new XSSFWorkbook(fin);
			sh=wb.getSheet(SheetName);
			row=sh.getRow(0);
			for (int c=0;c<row.getLastCellNum();c++)
			{
				cell=row.getCell(c);
				String cellVal=cell.getStringCellValue();
				if (cellVal.trim().equalsIgnoreCase(colName.trim()))
				{
					colNum=c;
					break;
				}
			}
			row=sh.getRow(rownum-1);
			cell=row.getCell(colNum);
			if (cell==null || cell.getCellType()==cell.CELL_TYPE_BLANK)
			{
				cellData="";
			}
			else if ( cell.getCellType()==cell.CELL_TYPE_STRING)
			{
				cellData=cell.getStringCellValue();
			}
			else if (cell.getCellType()==cell.CELL_TYPE_BOOLEAN)
			{
				cellData=String.valueOf(cell.getBooleanCellValue());
			}
			else if (cell.getCellType()==cell.CELL_TYPE_NUMERIC || cell.getCellType()==cell.CELL_TYPE_FORMULA)
			{
				if (HSSFDateUtil.isCellDateFormatted(cell))
				{
					double d1=cell.getNumericCellValue();
					Calendar cal=Calendar.getInstance();
					cal.setTime(HSSFDateUtil.getJavaDate(d1));
					String month=String.valueOf(cal.get(Calendar.MONTH)+1);
					String day=String.valueOf(cal.get(Calendar.DAY_OF_MONTH));
					String year=String.valueOf(cal.get(Calendar.YEAR));
					cellData=month+"/"+day+"/"+year;
				}
				else
				{
					cellData=String.valueOf(cell.getNumericCellValue());
				}
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fin.close();
				wb=null;
				sh=null;
				row=null;
				cell=null;
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return cellData;
	}
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	@SuppressWarnings("static-access")
	public String getCellValue(String SheetName,String colName,int rownum)
	{
		Sheet sh;
		Row row;
		Cell cell;
		int colNum = 0;
		String cellData=null;
		FileInputStream fin=null;
		try
		{
			sh=wb.getSheet(SheetName);
			row=sh.getRow(0);
			for (int c=0;c<row.getLastCellNum();c++)
			{
				cell=row.getCell(c);
				String cellVal=cell.getStringCellValue();
				if (cellVal.trim().equalsIgnoreCase(colName.trim()))
				{
					colNum=c;
					break;
				}
			}
			row=sh.getRow(rownum-1);
			cell=row.getCell(colNum);
			if ( cell.getCellType()==cell.CELL_TYPE_STRING)
			{
				cellData=cell.getStringCellValue();
			}
			else if (cell.getCellType()==cell.CELL_TYPE_BLANK)
			{
				cellData="";
			}
			else if (cell.getCellType()==cell.CELL_TYPE_BOOLEAN)
			{
				cellData=String.valueOf(cell.getBooleanCellValue());
			}
			else if (cell.getCellType()==cell.CELL_TYPE_NUMERIC || cell.getCellType()==cell.CELL_TYPE_FORMULA)
			{
				if (HSSFDateUtil.isCellDateFormatted(cell))
				{
					double d1=cell.getNumericCellValue();
					Calendar cal=Calendar.getInstance();
					cal.setTime(HSSFDateUtil.getJavaDate(d1));
					String month=String.valueOf(cal.get(Calendar.MONTH)+1);
					String day=String.valueOf(cal.get(Calendar.DAY_OF_MONTH));
					String year=String.valueOf(cal.get(Calendar.YEAR));
					cellData=month+"/"+day+"/"+year;
				}
				else
				{
					cellData=String.valueOf(cell.getNumericCellValue());
				}
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				sh=null;
				row=null;
				cell=null;
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return cellData;
	}
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public void setCellValue(String FileName,String SheetName,String colName,int rownum,String cellData)
	{
		Workbook wb;
		Sheet sh;
		Row row;
		Cell cell;
		int colNum=0;
		FileInputStream fin=null;
		FileOutputStream fout=null;
		try
		{
			fin=new FileInputStream(FileName);
			wb=new XSSFWorkbook(fin);
			sh=wb.getSheet(SheetName);
			if (sh==null)
			{
				sh=wb.createSheet(SheetName);
			}
			row=sh.getRow(0);
			for (int c=0;c<row.getLastCellNum();c++)
			{
				cell=row.getCell(c);
				String cellVal=cell.getStringCellValue();
				if (cellVal.trim().equalsIgnoreCase(colName.trim()))
				{
					colNum=c;
					break;
				}
			}
			row=sh.getRow(rownum-1);
			if (row==null)
			{
				row=sh.createRow(rownum-1);
			}
			cell=row.getCell(colNum);
			if (cell==null)
			{
				cell=row.createCell(colNum);
			}
			cell.setCellValue(cellData);
			fout=new FileOutputStream(FileName);
			wb.write(fout);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fin.close();
				fout.close();
				wb=null;
				sh=null;
				row=null;
				cell=null;
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
