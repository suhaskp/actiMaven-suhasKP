package driverscript;

import java.lang.reflect.Method;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;

import datatable.Datatable;
import testscripts.Initialize;
import utility.ApplicationIndependent;
import utility.ObjectMap;
import utility.ReportUtil;

public class DriverScript {
   public static WebDriver oBrowser;
   public static Properties config; 
   public static Properties verifytext; 
   public static ObjectMap objectmap; 
   public static String controllerFile;
   public static String testScriptFile;
   public static Datatable controller;
   public static Datatable testData;
   public static String testcaseid;
   public static String testcasename;
   public static String configdata;
   public static String objectmapdata;
   public static String verifytextdata;
   public static String testdatacolumn;
   public static String waitdata;
   public static String testResultStatus;
   public static String waitObjectNames;
   public static String waitTextValues;
   public static String waitTitleName;
   
   public static Logger log=Logger.getLogger("actiTime Automation");
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
    @BeforeSuite
    public void startAutomationSuite()
    {
     try
  	   {
    	 log.info("the startAutomationSuite method execution started...");
  		   String teststarttime=ApplicationIndependent.getDateTime("dd-MMM-yyyy hh:mm:ss a");
  		   String FileName=System.getProperty("user.dir")+"\\Results\\ResultReports\\ResultReports.html";
  		   ReportUtil.createReport(FileName, teststarttime, "Testing");
  	   } catch(Exception e)
  	   {
  		   log.error("there is an execition arised during execution of the method startAutomationSuite "+e);
  	  }
    }
    
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
    @BeforeClass
    public void loadFiles()
    {
    	 try
    	   {
    		 log.info("the loadFiles method execution started...");
    		 log.info("Load the Config properties file...");
    		   String configFileName=System.getProperty("user.dir")+"\\Configuration\\Config.properties";
    		   config=ApplicationIndependent.property(configFileName);
    		   log.info("Load the VerifyText properties file...");
    		   String verifytextFileName=System.getProperty("user.dir")+"\\TestScriptDataFiles\\VerifyText.properties";
    		   verifytext=ApplicationIndependent.property(verifytextFileName);
    		   log.info("Load the ObjectMap properties file...");
    		   String objectmapFileName=System.getProperty("user.dir")+"\\Objects\\ObjectMap.properties";
    		   objectmap=new ObjectMap(objectmapFileName);
    		   log.info("Create Object for Controller and TestData.....");
    		   controller=new Datatable();
    		   testData=new Datatable();
    	   } catch(Exception e)
    	   {
    		   log.error("there is an execition arised during execution of the method loadFiles "+e);
    	   }
    }
    
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
   @Test
   public void startExecuteScenarios()
   {
	   String startTime=null;
	   String endTime=null;
  	   try
  	   {
  		 log.info("The method startExecuteScenarios has started.....");
  		   ReportUtil.startSuite("Scenarios");
  		   controllerFile=System.getProperty("user.dir")+"\\Controller\\data_Controller.xlsx";
  		   int rc=controller.rowCount(controllerFile, "Scenarios");
  		   for (int tcid=0;tcid<rc;tcid++)
  		   {
  			   testcaseid=controller.getCellValue(controllerFile, "Scenarios", "TestcaseID", tcid+2);
  			   testcasename=controller.getCellValue(controllerFile, "Scenarios", "TestcaseName", tcid+2);
  			   String description=controller.getCellValue(controllerFile, "Scenarios", "Description", tcid+2);
  			   String runstatus=controller.getCellValue(controllerFile, "Scenarios", "RunStatus", tcid+2);
  			   System.out.println("testcaseid  "+testcaseid);
  			   System.out.println("testcasename  "+testcasename);
  			   System.out.println("description  "+description);
  			   System.out.println("runstatus  "+runstatus);
  			   System.out.println("+++++++++++++++++++++++++++");
  			   if (runstatus.equalsIgnoreCase("yes"))
  			   {
  				   testScriptFile=System.getProperty("user.dir")+"\\TestScriptDataFiles\\"+testcasename+".xlsx";
  				   Class driver[]=new Class[1];
  				   driver[0]=WebDriver.class;
  				   oBrowser=Initialize.lauch();
  				   startTime=ApplicationIndependent.getDateTime("dd-MMM-yyyy hh:mm:ss a");
  				   int rc1=controller.rowCount(testScriptFile, testcaseid);
  				   for (int tsid=0;tsid<rc1;tsid++)
  				   {
  					   String testscriptid=controller.getCellValue(testScriptFile, testcaseid, "TestScriptID", tsid+2);
  					   String testdescription=controller.getCellValue(testScriptFile, testcaseid, "Description", tsid+2);
  					   String testmethod=controller.getCellValue(testScriptFile, testcaseid, "MethodName", tsid+2);
  					   String testpkgclass=controller.getCellValue(testScriptFile, testcaseid, "ClassName", tsid+2);
  					   configdata=controller.getCellValue(testScriptFile, testcaseid, "ConfigData", tsid+2);
  					   objectmapdata=controller.getCellValue(testScriptFile, testcaseid, "ObjectMapData", tsid+2);
  					   verifytextdata=controller.getCellValue(testScriptFile, testcaseid, "VerifyTextData", tsid+2);
  					   waitObjectNames=controller.getCellValue(testScriptFile, testcaseid, "WaitObject", tsid+2);
  					   waitTextValues=controller.getCellValue(testScriptFile, testcaseid, "WaitTextValue", tsid+2);
  					   waitTitleName=controller.getCellValue(testScriptFile, testcaseid, "WaitTitle", tsid+2);
  					   testdatacolumn=controller.getCellValue(testScriptFile, testcaseid, "TestDataColumn", tsid+2);
  					   System.out.println("testscriptid  "+testscriptid);
  					   System.out.println("testdescription  "+testdescription);
  					   System.out.println("testmethod  "+testmethod);
  					   System.out.println("testpkgclass  "+testpkgclass);
  					   System.out.println("configdata  "+configdata);
  					   System.out.println("objectmapdata  "+objectmapdata);
  					   System.out.println("verifytextdata  "+verifytextdata);
  					   System.out.println("waitdata  "+waitdata);
  					   System.out.println("testdatacolumn  "+testdatacolumn);
  					   System.out.println("++++++++++++++++++++++++++++++");
  					   Class cls=Class.forName(testpkgclass);
  					   Object obj=cls.newInstance();
  					   Method method=obj.getClass().getMethod(testmethod, driver);
  					   log.info("The Execution of the method "+testmethod+" has started ....");
  					   String result=(String) method.invoke(obj, oBrowser);
  					 log.info("The Execution Result of the method "+testmethod+"    "+result);
  					   endTime=ApplicationIndependent.getDateTime("dd-MMM-yyyy hh:mm:ss a");
  					   String FileName="Screenshot_"+testscriptid+"_"+testmethod+".png";
  					   String path=System.getProperty("user.dir")+"\\Results\\ScreenShots"+"\\"+FileName;
  					   ReportUtil.addArrayList(testdescription, testmethod, testpkgclass, result, path);
  					  if (result.equalsIgnoreCase("fail"))
  					  {
  						  ApplicationIndependent.getScreenShots(oBrowser, path);
  					  }
  					testResultStatus+=result;
  				   }
  				   log.info("++++++++++++++++++++++++++++++++++++++++++++++++++++");
  				   if (testResultStatus.contains("Fail"))
  				   {
  					   ReportUtil.writeTestResults(testcaseid, testcasename, "Fail", startTime, endTime);
  				   }
  				   else
  				   {
  					 ReportUtil.writeTestResults(testcaseid, testcasename, "Pass", startTime, endTime);
  				   }
  			   }
  		   }
  	   } catch(Exception e)
  	   {
  		 log.error("there is an execition arised during execution of the method startExecuteScenarios "+e);
  	   }
  	   
    }

	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
   @AfterSuite
   public void endAutomationSuite()
   {
	   String endTime;
	   try
	   {
		   log.info("The method endAutomationSuite has started.....");
		   ReportUtil.endSuite();
		   endTime=ApplicationIndependent.getDateTime("dd-MMM-yyyy hh:mm:ss a");
		   ReportUtil.updateEndTime(endTime);
	   } catch(Exception e)
	   {
		   log.error("there is an execition arised during execution of the method endAutomationSuite "+e);
	   }
   }
}
