package utility;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;

public class ObjectMap {
	Properties prop=null;
	FileInputStream fin=null;
	public ObjectMap(String FileName)
	{
		
		try
		{
			fin=new FileInputStream(FileName);
			prop=new Properties();
			prop.load(fin);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public By getLocator(String Elementname)
	{
		By by = null;
		try
		{
			String locatordetail=prop.getProperty(Elementname);
			String locator[]=locatordetail.split(">");
			String locatorname=locator[0];
			String locatorvalue=locator[1];
			if (locatorname.equalsIgnoreCase("name"))
			{
				by=By.name(locatorvalue);
			}
			else if (locatorname.equalsIgnoreCase("id"))
			{
				by=By.id(locatorvalue);
			}
			else if (locatorname.equalsIgnoreCase("xpath"))
			{
				by=By.xpath(locatorvalue);
			}
			else if (locatorname.equalsIgnoreCase("linktext"))
			{
				by=By.linkText(locatorvalue);
			}
			else if (locatorname.equalsIgnoreCase("css"))
			{
				by=By.cssSelector(locatorvalue);
			}
			else
			{
				System.out.println("An invalid Element has passed to a Method...........");
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return by;
	}

}
