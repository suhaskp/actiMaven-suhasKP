package utility;

import java.io.*;
import java.util.*;

public class ReportUtil {
	public static String reportFileName;
	public static String currentDirectory;
	public static String scenarioName;
	public static Properties config1;
	public static ArrayList<String> description=new ArrayList<String>();
	public static ArrayList<String> methods=new ArrayList<String>();
	public static ArrayList<String> pkgclass=new ArrayList<String>();
	public static ArrayList<String> status=new ArrayList<String>();
	public static ArrayList<String> screenshotpath=new ArrayList<String>();
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static void createReport(String FileName,String teststarttime,String environment)
	{
		BufferedWriter bw=null;
		try
		{
			reportFileName=FileName;
			currentDirectory=reportFileName.substring(0, reportFileName.lastIndexOf("\\"));
			String configFileName=System.getProperty("user.dir")+"\\Configuration\\Config.properties";
			config1=ApplicationIndependent.property(configFileName);
			bw=new BufferedWriter(new FileWriter(reportFileName));
			bw.write("<html>");
			bw.write("<head><title>actiTime Automation Results</title></head>");
			bw.newLine();
			bw.write("<body>");
			bw.write("<h1 align=center>actiTime Automation Results</h1>");
			bw.write("<table border=2>");
			bw.newLine();
			bw.write("<h3>Automation Summary</h3>");
			bw.write("<tr>");
			bw.write("<th>Item Name</th>");
			bw.write("<th>Item Value</th>");
			bw.write("</tr>");
			bw.write("<tr>");
			bw.write("<td>Application Name</td>");
			bw.write("<td>"+config1.getProperty("applicationName")+"</td>");
			bw.write("</tr>");
			bw.write("<tr>");
			bw.write("<td>Application Version</td>");
			bw.write("<td>"+config1.getProperty("applicationversion")+"</td>");
			bw.write("</tr>");
			bw.write("<tr>");
			bw.write("<td>Browser Name</td>");
			bw.write("<td>"+config1.getProperty("browsername")+"</td>");
			bw.write("</tr>");
			bw.write("<tr>");
			bw.write("<td>Application URL</td>");
			bw.write("<td>"+config1.getProperty("url")+"</td>");
			bw.write("</tr>");
			bw.write("<tr>");
			bw.write("<td>Environment</td>");
			bw.write("<td>"+environment+"</td>");
			bw.write("</tr>");
			bw.write("<tr>");
			bw.write("<td>Start Time</td>");
			bw.write("<td>"+teststarttime+"</td>");
			bw.write("</tr>");
			bw.write("<tr>");
			bw.write("<td>End Time</td>");
			bw.write("<td>END_TIME</td>");
			bw.write("</tr>");
			bw.write("</table>");
			bw.newLine();
			bw.write("</body>");
			bw.write("</html>");
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			if (! (bw==null))
			{
				try{
					bw.flush();
					bw.close();
				}catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}
	}
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static void startSuite(String suiteName)
	{
		BufferedWriter bw=null;
		try
		{
			scenarioName=suiteName;
			bw=new BufferedWriter(new FileWriter(reportFileName,true));
			bw.write("<html>");
			bw.newLine();
			bw.write("<body>");
			bw.write("<table border=2 width=100%>");
			bw.newLine();
			bw.write("<h3>TestScript Detail Results</h3>");
			bw.write("<tr>");
			bw.write("<th width=10%>Testcase ID</th>");
			bw.write("<th width=20%>Testcase Name</th>");
			bw.write("<th width=20%>Status</th>");
			bw.write("<th width=25%>Test Start Time</th>");
			bw.write("<th width=25%>Test End time</th>");
			bw.write("</tr>");
			bw.newLine();
			bw.write("</body>");
			bw.write("</html>");
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				bw.flush();
				bw.close();
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}

	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static void endSuite()
	{
		BufferedWriter bw=null;
		try
		{
			bw=new BufferedWriter(new FileWriter(reportFileName,true));
			bw.write("</table>");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				bw.flush();
				bw.close();
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static void addArrayList(String desc,String methodname,String classname,String teststatus,String screenshot)
	{
		description.add(desc);
		methods.add(methodname);
		pkgclass.add(classname);
		status.add(teststatus);
		screenshotpath.add(screenshot);
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static void writeTestResults(String tcid,String tcname,String teststatus,String starttime,String endtime)
	{
		BufferedWriter bw=null;
		String FilePath = null;
		try
		{
			FilePath=currentDirectory+"\\"+scenarioName+"_"+tcname+"_"+"Results"+".html";
			bw=new BufferedWriter(new FileWriter(FilePath));
			bw.write("<html>");
			bw.newLine();
			bw.write("<body>");
			bw.write("<h1 align=center>"+tcname+" Automation Result</h1>");
			bw.write("<table border=2 width=100%>");
			bw.newLine();
			bw.write("<h3>TestScript "+tcname+"Detail Results</h3>");
			bw.write("<tr>");
			bw.write("<th width=10%>TestScript ID</th>");
			bw.write("<th width=20%>Description</th>");
			bw.write("<th width=15%>Method Name</th>");
			bw.write("<th width=20%>PackageClass Name</th>");
			bw.write("<th width=10%>Status</th>");
			bw.write("<th width=25%>ScreenShot Name</th>");
			bw.write("</tr>");
			bw.newLine();
			for (int i=0;i<methods.size();i++)
			{
				bw.write("<tr>");
				if (methods.get(i)!=null)
				{
					if (i>9)
					{
						bw.write("<td width=10%>TS"+i+"</td>");
					}
					else
					{
						bw.write("<td width=10%>TS0"+(i+1)+"</td>");
					}
					bw.write("<td width=20%>"+description.get(i)+"</td>");
					bw.write("<td width=15%>"+methods.get(i)+"</td>");
					bw.write("<td width=20%>"+pkgclass.get(i)+"</td>");
					
					if (status.get(i).equalsIgnoreCase("pass"))
					{
						bw.write("<td width=10%>"+status.get(i)+"</td>");
						bw.write("<td width=25%>&nbsp</td>");
					}
					else
					{
						bw.write("<td width=10%>"+status.get(i)+"</td>");
						bw.write("<td width=25%><a href=file:///"+screenshotpath.get(i)+">Screenshot</a></td>");
					}
				}
				bw.write("</tr>");
			}
			bw.write("</body>");
			bw.write("</html>");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				bw.flush();
				bw.close();
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		try
		{
			bw=new BufferedWriter(new FileWriter(reportFileName,true));
			bw.write("<tr>");
			bw.write("<td width=10%>"+tcid+"</td>");
			bw.write("<td width=20% align=center>"+tcname+"</td>");
			bw.write("<td width=20% align=center><a href=file:///"+FilePath+">"+teststatus+"</a></td>");
			bw.write("<td width=25%>"+starttime+"</td>");
			bw.write("<td width=25%>"+endtime+"</td>");
			
			bw.write("</tr>");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				bw.flush();
				bw.close();
			}catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
		 description=new ArrayList<String>();
		 methods=new ArrayList<String>();
		 pkgclass=new ArrayList<String>();
		 status=new ArrayList<String>();
		 screenshotpath=new ArrayList<String>();
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Type:
	 * Purpose:
	 * Description :
	 */
	public static void updateEndTime(String endTime)
	{
		try
		{
			StringBuffer str=new StringBuffer();
			FileInputStream fin=new FileInputStream(reportFileName);
			DataInputStream dis=new DataInputStream(fin);
			InputStreamReader fr=new InputStreamReader(dis);
			BufferedReader br=new BufferedReader(fr);
			String strLine=null;
			while((strLine=br.readLine())!=null)
			{
				if (strLine.indexOf("END_TIME")!=-1)
				{
					strLine=strLine.replace("END_TIME", endTime);
				}
				str.append(strLine);
			}
			fin.close();
			FileOutputStream fout=new FileOutputStream(reportFileName);
			DataOutputStream out=new DataOutputStream(fout);
			out.writeBytes(str.toString());
			
			fout.close();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
