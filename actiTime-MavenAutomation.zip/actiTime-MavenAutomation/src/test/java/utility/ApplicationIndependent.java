package utility;

import java.text.SimpleDateFormat;
import java.util.*;
import java.io.*;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ApplicationIndependent {

/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static String getDateTime(String DateFormat)
	{
		String sDateTime = null;
		try
		{
			Calendar cal=Calendar.getInstance();
			SimpleDateFormat sdf=new SimpleDateFormat(DateFormat);
			sDateTime=sdf.format(cal.getTime());
		} catch(Exception e)
		{
			e.printStackTrace();
		}
		return sDateTime;
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static Properties property(String FileName)
	{
		Properties prop=null;
		FileInputStream fin=null;
		try
		{
			fin=new FileInputStream(FileName);
			prop=new Properties();
			prop.load(fin);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return prop;
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static boolean getScreenShots(WebDriver oBrowser,String FileName)
	{
		File srcFile;
		try
		{
			srcFile=(File) ((TakesScreenshot) oBrowser).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(srcFile, new File(FileName));
			return true;
		}catch(Exception e)
		{
			return false;
		}
	
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static void waitFor(long seconds)
	{
		
		try
		{
			long miliseconds=seconds*1000;
			Thread.sleep(miliseconds);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
