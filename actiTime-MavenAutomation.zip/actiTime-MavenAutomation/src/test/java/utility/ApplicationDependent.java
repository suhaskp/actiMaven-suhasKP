package utility;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ApplicationDependent {
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static  boolean isElementPresent(WebDriver oBrowser,By by)
	{
		try
		{
			oBrowser.findElement(by);
			return true;
		}catch(Exception e)
		{
			return false;
		}
	}

	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static void waitTitle(WebDriver oBrowser,String title)
	{
		try
		{
			WebDriverWait wait=new WebDriverWait(oBrowser, 60);
			wait.until(ExpectedConditions.titleContains(title));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static void waitElementText(WebDriver oBrowser,WebElement oEle,String text)
	{
		try
		{
			WebDriverWait wait=new WebDriverWait(oBrowser, 60);
			wait.until(ExpectedConditions.textToBePresentInElement(oEle, text));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static void waitElementValue(WebDriver oBrowser,WebElement oEle,String text)
	{
		try
		{
			WebDriverWait wait=new WebDriverWait(oBrowser, 60);
			wait.until(ExpectedConditions.textToBePresentInElementValue(oEle, text));
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
