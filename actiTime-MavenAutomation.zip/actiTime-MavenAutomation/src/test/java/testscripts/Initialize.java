package testscripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import utility.ApplicationDependent;
import driverscript.DriverScript;


public class Initialize extends DriverScript{
  public static WebDriver oBrowser;
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static WebDriver lauch()
	{
		try
		{
			String browserType=config.getProperty("browsertype");
			switch(browserType.toLowerCase())
			{
			case "ff":
				oBrowser=new FirefoxDriver();
				break;
			case "ch":
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Library\\driver\\chromedriver.exe");
				oBrowser=new ChromeDriver();
				break;
			case "ie":
				System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"\\Library\\driver\\IEDriverServer.exe");
				oBrowser=new InternetExplorerDriver();
				break;
			default:
				 System.out.println("An invalid Browser Type has entered................");
			}
			
		} catch(Exception e)
		{
			log.error("there is an exception arised during the execution of the method lauch "+e);
		}
		return oBrowser;
		
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static String navigate(WebDriver oBrowser)
	{
		String expected,actual;
		String waittitle;
		try
		{
			expected=verifytext.getProperty(verifytextdata);
			waittitle=verifytext.getProperty(waitTitleName);
			oBrowser.navigate().to(config.getProperty(configdata));
			ApplicationDependent.waitTitle(oBrowser, waittitle);
			actual=oBrowser.getTitle();
			if (actual.equalsIgnoreCase(expected))
			{
				return "Pass";
			}
			else
			{
				return "Fail";
			}
		} catch(Exception e)
		{
			log.error("there is an exception arised during the execution of the method navigate "+e);
		}
		return "Pass";
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static String closeApplication(WebDriver oBrowser)
	{
		try
		{
			oBrowser.close();
		} catch(Exception e)
		{
			log.error("there is an exception arised during the execution of the method closeApplication "+e);
			return "Fail";
		}
		return "Pass";
	}
}
