package testscripts;

import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


import org.openqa.selenium.WebElement;

import driverscript.DriverScript;
import utility.ApplicationDependent;

public class LoginLogout extends DriverScript{
	public static WebDriver oBrowser;
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static String login(WebDriver oBrowser)
	{
		try
		{
			Pattern objectPattern=Pattern.compile(",");
			String objectArr[]=objectPattern.split(objectmapdata);
			
			Pattern testDataPattern=Pattern.compile(",");
			String testDataArr[]=testDataPattern.split(testdatacolumn);
			
			Pattern waitObjectPattern=Pattern.compile(",");
			String waitObjectArr[]=waitObjectPattern.split(waitObjectNames);
			
			Pattern waitTextValue=Pattern.compile(",");
			String waitTextValueArr[]=waitTextValue.split(waitTextValues);
			
			String user=testData.getCellValue(testScriptFile, "testdata", testDataArr[0], 2);
			String pwd=testData.getCellValue(testScriptFile, "testdata", testDataArr[1], 2);
			oBrowser.findElement(objectmap.getLocator(objectArr[0])).sendKeys(new String[] {user});
			oBrowser.findElement(objectmap.getLocator(objectArr[1])).sendKeys(new String[] {pwd});
			oBrowser.findElement(objectmap.getLocator(objectArr[2])).click();
			WebElement oEle=oBrowser.findElement(objectmap.getLocator(waitObjectArr[0]));
			ApplicationDependent.waitElementText(oBrowser, oEle, verifytext.getProperty(waitTextValueArr[0]));
			
			String actual=verifytext.getProperty(verifytextdata);
			By by=By.xpath("//td[text()="+"'"+actual+"'"+"]");
			if (ApplicationDependent.isElementPresent(oBrowser, by)==true)
			{
				return "Pass";
			}
			else
			{
				return "Fail";
			}
		} catch(Exception e)
		{
			log.error("there is an exception arised during the execution of the method login "+e);
		}
		return "Pass";
	}
	
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static String logout(WebDriver oBrowser)
	{
		String expected,actual;
		String waittitle;
		try
		{
			Pattern objectPattern=Pattern.compile(",");
			String objectArr[]=objectPattern.split(objectmapdata);
			System.out.println(objectArr[0]);
			expected=verifytext.getProperty(verifytextdata);
			oBrowser.findElement(objectmap.getLocator(objectArr[0])).click();
			waittitle=verifytext.getProperty(waitTitleName);
			ApplicationDependent.waitTitle(oBrowser, waittitle);
			actual=oBrowser.getTitle();
			if (actual.equalsIgnoreCase(expected))
			{
				return "Pass";
			}
			else
			{
				return "Fail";
			}
		}catch(Exception e)
		{
			log.error("there is an exception arised during the execution of the method logout "+e);
		}
		return "Pass";
	}
}
