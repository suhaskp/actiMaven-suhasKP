package testscripts;

import java.util.regex.Pattern;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import driverscript.DriverScript;
import utility.ApplicationDependent;

public class Users extends DriverScript{

	public static WebDriver oBrowser;
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static String createUser(WebDriver oBrowser)
	{
		try
		{
			Pattern objectPattern=Pattern.compile(",");
			String objectArr[]=objectPattern.split(objectmapdata);
			
			Pattern testDataPattern=Pattern.compile(",");
			String testDataArr[]=testDataPattern.split(testdatacolumn);
			oBrowser.findElement(objectmap.getLocator(objectArr[0])).click();
			Thread.sleep(4000);
			oBrowser.findElement(objectmap.getLocator(objectArr[1])).click();
			Thread.sleep(2000);
			oBrowser.findElement(objectmap.getLocator(objectArr[2])).sendKeys(new String[] {testData.getCellValue(testScriptFile, "testdata", testDataArr[0], 2)});
			oBrowser.findElement(objectmap.getLocator(objectArr[3])).sendKeys(new String[] {testData.getCellValue(testScriptFile, "testdata", testDataArr[1], 2)});
			oBrowser.findElement(objectmap.getLocator(objectArr[4])).sendKeys(new String[] {testData.getCellValue(testScriptFile, "testdata", testDataArr[2], 2)});
			oBrowser.findElement(objectmap.getLocator(objectArr[5])).sendKeys(new String[] {testData.getCellValue(testScriptFile, "testdata", testDataArr[3], 2)});
			oBrowser.findElement(objectmap.getLocator(objectArr[6])).sendKeys(new String[] {testData.getCellValue(testScriptFile, "testdata", testDataArr[4], 2)});
			oBrowser.findElement(objectmap.getLocator(objectArr[7])).sendKeys(new String[] {testData.getCellValue(testScriptFile, "testdata", testDataArr[5], 2)});
			oBrowser.findElement(objectmap.getLocator(objectArr[8])).click();
			Thread.sleep(5000);
			String userLinkName=verifytext.getProperty(verifytextdata);
			By by=By.xpath("//div/span[text()="+"'"+userLinkName+"'"+"]");
			if (ApplicationDependent.isElementPresent(oBrowser, by)==true)
			{
				return "Pass";
			}
			else
			{
				return "Fail";
			}
		}catch(Exception e)
		{
			log.error("there is an exception arised during the execution of the method createUser "+e);
		}
		return "Pass";
	}
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static String modifyUser(WebDriver oBrowser)
	{
		try
		{
			Pattern objectPattern=Pattern.compile(",");
			String objectArr[]=objectPattern.split(objectmapdata);
			
			Pattern testDataPattern=Pattern.compile(",");
			String testDataArr[]=testDataPattern.split(testdatacolumn);
			oBrowser.findElement(objectmap.getLocator(objectArr[0])).click();
			Thread.sleep(2000);
			oBrowser.findElement(objectmap.getLocator(objectArr[1])).sendKeys(new String[] {testData.getCellValue(testScriptFile, "testdata", testDataArr[0], 2)});
			oBrowser.findElement(objectmap.getLocator(objectArr[2])).sendKeys(new String[] {testData.getCellValue(testScriptFile, "testdata", testDataArr[1], 2)});
			oBrowser.findElement(objectmap.getLocator(objectArr[3])).click();
			Thread.sleep(5000);
			String userLinkName=verifytext.getProperty(verifytextdata);
			
			By by=By.xpath("//div/span[text()="+"'"+userLinkName+"'"+"]");
			if (ApplicationDependent.isElementPresent(oBrowser, by)==true)
			{
				return "Pass";
			}
			else
			{
				return "Fail";
			}
		} catch(Exception e)
		{
			log.error("there is an exception arised during the execution of the method modifyUser "+e);
		}
		return "Pass";
	}
	/*
	 * Created By:
	 * Created Date:
	 * Reviewed By:
	 * Parameters:
	 * Return Value:
	 * Purpose:
	 * Description
	 */
	public static String deleteUser(WebDriver oBrowser)
	{
		try
		{
			Pattern objectPattern=Pattern.compile(",");
			String objectArr[]=objectPattern.split(objectmapdata);

			oBrowser.findElement(objectmap.getLocator(objectArr[0])).click();
			Thread.sleep(2000);
			oBrowser.findElement(objectmap.getLocator(objectArr[1])).click();
			Thread.sleep(2000);
			Alert alert=oBrowser.switchTo().alert();
		//	System.out.println("Text of the alert window :"+alert.getText());
			alert.accept();
			Thread.sleep(2000);
			String userLinkName=verifytext.getProperty(verifytextdata);
			By by=By.xpath("//div/span[text()="+"'"+userLinkName+"'"+"]");
			if (ApplicationDependent.isElementPresent(oBrowser, by)==false)
			{
				return "Pass";
			}
			else
			{
				return "Fail";
			}
		}catch(Exception e)
		{
			log.error("there is an exception arised during the execution of the method deleteUser "+e);
		}
		return "Pass";
	}
}
